const express = require('express');
const router = express.Router();

// Fake user store (replace with real DB in production)
const users = [{ username: 'admin', password: 'admin123', role: 'admin' }];

router.post('/login', (req, res) => {
  const { username, password } = req.body;
  const user = users.find(u => u.username === username && u.password === password);

  if (user) {
    req.session.user = { username: user.username, role: user.role };
    res.json({ success: true });
  } else {
    res.status(401).json({ error: 'Invalid credentials' });
  }
});

router.get('/me', (req, res) => {
  res.json(req.session.user || null);
});

module.exports = router;
