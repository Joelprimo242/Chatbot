const express = require('express');
const router = express.Router();
const { Configuration, OpenAIApi } = require('openai');

const configuration = new Configuration({ apiKey: process.env.OPENAI_API_KEY });
const openai = new OpenAIApi(configuration);

router.post('/', async (req, res) => {
  const session = req.session;
  session.history = session.history || [];

  const { message } = req.body;
  session.history.push({ role: 'user', content: message });

  const recentMessages = session.history.slice(-10);

  try {
    const completion = await openai.createChatCompletion({
      model: 'gpt-4',
      messages: recentMessages,
    });

    const reply = completion.data.choices[0].message;
    session.history.push(reply);

    res.json({ reply });
  } catch (err) {
    res.status(500).json({ error: 'Chat error', details: err.message });
  }
});

module.exports = router;
