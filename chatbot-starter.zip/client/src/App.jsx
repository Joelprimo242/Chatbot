import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './App.css';

function App() {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState('');

  const sendMessage = async () => {
    const res = await axios.post('http://localhost:5000/api/chat', { message: input }, { withCredentials: true });
    setMessages([...messages, { role: 'user', content: input }, res.data.reply]);
    setInput('');
  };

  return (
    <div className="min-h-screen bg-gray-100 p-4">
      <div className="max-w-2xl mx-auto bg-white shadow-xl rounded-2xl p-6">
        <h1 className="text-2xl font-bold mb-4">Chatbot</h1>
        <div className="space-y-2 h-96 overflow-y-scroll border p-2">
          {messages.map((m, i) => (
            <div key={i} className={`p-2 rounded ${m.role === 'user' ? 'bg-blue-200' : 'bg-gray-200'}`}>{m.content}</div>
          ))}
        </div>
        <div className="mt-4 flex gap-2">
          <input
            className="flex-1 border px-3 py-2 rounded-lg"
            value={input}
            onChange={e => setInput(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && sendMessage()}
          />
          <button className="bg-blue-600 text-white px-4 py-2 rounded-xl" onClick={sendMessage}>Send</button>
        </div>
      </div>
    </div>
  );
}

export default App;
